import 'dart:io';


bool checkFib(List<int> list){
   for(int n = 2; n < list.length; n++){ 
      if ((list[n - 1] + list[n - 2]) != list[n]){
        return false;
   }      
  }
   return true;

}
void main() {
  
	print("Fibbonacci Checker\n");

  List<int> list = new List();
  print("Enter size of list(size must be greater than 3 less than 10): ");
  int size = int.parse(stdin.readLineSync());
  if(size <= 3 || size >= 10){
    print("Invalid size");
  }else{
    for(int n = 0; n < size;n++){int x = n+1;//pwede gyapon n=1
      print("Enter number $x: ");//tapos kung n=1 mahimong print "enter number $n:" na dayun
      list.add(int.parse(stdin.readLineSync()));
    }
    print(list);
    print(checkFib(list));
  }  

}